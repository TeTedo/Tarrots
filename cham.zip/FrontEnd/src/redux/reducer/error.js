export const error = {};
