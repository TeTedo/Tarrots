import axios from "axios";
const callAirData = () => {
  return async (dispatch, getState) => {};
};

export const apiAction = { callAirData };
