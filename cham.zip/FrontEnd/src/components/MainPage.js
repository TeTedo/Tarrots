import React from "react";
import MainEntrance from "./Main/MainEntrance";
const MainPage = () => {
  return (
    <div>
      <MainEntrance></MainEntrance>
    </div>
  );
};

export default MainPage;
