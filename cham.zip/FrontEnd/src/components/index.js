import MainPage from "./MainPage";
import NavBar from "./NavBar";
import Shoppage from "./Shoppage";
export { MainPage, NavBar, Shoppage };
