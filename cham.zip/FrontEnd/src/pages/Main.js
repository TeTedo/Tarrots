import React from "react";
import { MainPage } from "../components";
const Main = () => {
  return (
    <div>
      <MainPage></MainPage>
    </div>
  );
};

export default Main;
