import React from "react";

const Game = () => {
  return <div>Game</div>;
};

export default Game;
