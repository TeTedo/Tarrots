import SideBar from "./SideBar";
import Body from "./Body";
export { SideBar, Body };
